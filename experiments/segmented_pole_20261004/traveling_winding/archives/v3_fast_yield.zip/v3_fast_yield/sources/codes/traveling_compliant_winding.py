"""Experimental travelling formation window with measured-shape compliance.

Formation and rolling are independent coordinates. Known pipe axes/contact
history are explicitly simulation inputs; this is not the unchanged 2023 law.
All commands still use position targets and the existing Yamada material field.
"""
from dataclasses import dataclass, asdict
import math
import numpy as np

from three_segment_incremental import IncrementalThreeSegmentController, integrated_field
from spatial_bishop_backbone import SpatialBishopBackbone
from segmented_pole_backbone import smoothstep


@dataclass(frozen=True)
class FormationOptions:
    joints_per_second: float = .4
    maximum_lead: float = 2.
    recovery: float = .35
    release_distance_links: float = 3.
    nominal: str = 'helix'


class TravelingCompliantWinding(IncrementalThreeSegmentController):
    def __init__(self, *args, pitch_mm=220., formation=FormationOptions(), **kwargs):
        super().__init__(*args, **kwargs)
        self.formation = formation
        self.pitch_mm = pitch_mm
        self.progress = float(self.initial_front)
        self.formation_weights = np.zeros(self.n)
        self.formation_weights[:self.initial_front] = 1.
        self.body_axis = -self.target
        p = np.asarray(args[0]['points_mm'])[:self.initial_front+2]-self.corner
        r = p-(p@self.body_axis)[:, None]*self.body_axis
        self.winding = float(np.sign(np.sum(np.cross(r[:-1], r[1:])@self.body_axis)))
        self.radius_reference = float(np.median(np.linalg.norm(r, axis=1)))
        # Select handedness from the actually wrapped front, not global phase 0.
        q = np.asarray(kwargs['measured'])
        candidates = []
        for sign in (-1., 1.):
            a, b = self.helix_basis(self.radius_reference, sign)
            fit = np.linalg.lstsq(np.column_stack([a, b])[:self.initial_front], q[:self.initial_front], rcond=None)[0]
            phase = math.atan2(fit[1], fit[0])
            error = np.linalg.norm((a*np.cos(phase)+b*np.sin(phase)-q)[:self.initial_front])
            candidates.append((error, sign, phase))
        _, self.pitch_sign, self.helix_phase = min(candidates)

    def helix_basis(self, radius, sign):
        h = sign*self.pitch_mm/(2*np.pi)
        kappa, tau = radius/(radius*radius+h*h), h/(radius*radius+h*h)
        nodes = np.r_[0., np.cumsum(self.links)]
        length, mid = nodes[2:]-nodes[:-2], (nodes[2:]+nodes[:-2])/2
        amplitude = kappa*length*np.sinc(tau*length/(2*np.pi))
        parity = np.arange(self.n) % 2
        a = -amplitude*np.where(parity, np.cos(tau*mid), np.sin(tau*mid))
        b = -amplitude*np.where(parity, -np.sin(tau*mid), np.cos(tau*mid))
        return a, b

    def update_boundaries(self, points, contact_window, dt):
        ds, distance, ps, axial = self.distances(points[1:-1])
        history = np.asarray(contact_window)
        target_contact = bool(len(history) >= 40 and np.mean(np.any(history[-40:, 1, :self.front+1] > .1, axis=1)) >= .9)
        region = (distance+10 < ds) & (distance < self.radius+29+15) & (axial > self.radius/2)
        prefix = self.initial_front
        while prefix < self.n and region[prefix]:
            prefix += 1
        old = [self.front, self.rear]
        # Permit forming BEFORE contact, but do not call its progress transfer.
        if target_contact:
            limit = min(self.n, prefix+self.formation.maximum_lead, self.rear)
            self.progress = max(self.progress, min(limit,
                                self.progress+dt*self.formation.joints_per_second))
        self.formation_weights = smoothstep(np.clip(self.progress-np.arange(self.n), 0., 1.))
        self.front = min(self.n, int(math.ceil(self.progress-1e-9)))
        room = self.rear-self.front < self.middle_max
        remaining_contact = bool(len(history) and np.any(history[-1, 0, self.rear+2:] > .1))
        # Rear reserve shrinks only after a physically transferred front grows.
        reserve = max(0, 6-max(0, prefix-8))
        near = self.rear < self.n and ps[self.rear] > -self.formation.release_distance_links*self.link
        release = (self.progress > self.initial_front+.5 and target_contact and room and near
                   and (remaining_contact or prefix >= 12) and self.n-self.rear > reserve)
        self.rear_ready = self.rear_ready+dt if release else 0.
        if self.rear_ready >= .6-1e-9:
            self.middle_reference[self.rear] = self.last_target[self.rear]
            self.rear += 1
            self.rear_ready = 0.
        if old != [self.front, self.rear]:
            self.events.append(dict(time=self.elapsed, old=old, new=[self.front,self.rear],
                actual_prefix=prefix, formation_progress=self.progress, release=release))
        return dict(actual_transfer=region, actual_prefix=prefix, formation_progress=self.progress,
                    target_contact=target_contact, release_allowed=release, rear_reserve=reserve,
                    release_near=near, remaining_source_contact=remaining_contact, middle_room=room)

    def rolling_observation(self, geometry, measured, observed):
        points = np.asarray(geometry['points_mm'])
        bone = SpatialBishopBackbone(points, self.links)
        _, rotation = bone.material_field(measured)
        relative = points[1:-1]-self.corner
        radial = relative-(relative@self.body_axis)[:, None]*self.body_axis
        distance = np.linalg.norm(radial, axis=1)
        # Wrapped-front feedback updates the nominal radius. Incoming connector
        # distances must not enlarge the whole front's cross section.
        radius = float(np.median(distance[:self.initial_front]))
        self.radius_reference += .15*(radius-self.radius_reference)
        a, b = self.helix_basis(self.radius_reference, self.pitch_sign)
        fit = np.linalg.lstsq(np.column_stack([a,b])[:self.initial_front], measured[:self.initial_front], rcond=None)[0]
        self.helix_phase = math.atan2(fit[1],fit[0])
        nominal_angles = a*np.cos(self.helix_phase)+b*np.sin(self.helix_phase)
        nominal = self.material_integrals(self.forward_points(nominal_angles), nominal_angles)
        h = abs(self.pitch_mm)/(2*np.pi)
        alpha = math.atan2(h,self.radius_reference)
        kappa = self.radius_reference/(self.radius_reference**2+h*h)
        field = np.zeros_like(bone.field)
        for j, frame in enumerate(bone.mid_frames):
            normal = radial[j]/max(distance[j],1e-9)
            tangent = frame[:,0]
            desired_tangent = self.winding*np.cos(alpha)*np.cross(self.body_axis,normal)+np.sin(alpha)*self.body_axis
            derivative = -kappa*normal+(desired_tangent-tangent*(desired_tangent@tangent))/(2*self.link)
            field[j+1] = derivative @ (frame[:,1:]@rotation)
        supported = integrated_field(bone,field)
        ramp = float(smoothstep(self.elapsed/1.6))
        # Existing support keeps the successful measured-axis recovery law.
        # New joints have an explicit travelling activation and a finite
        # recovery rate: actual deformation remains in every target update.
        gain = self.formation.recovery*self.formation_weights
        gain[:self.initial_front] = .1*ramp
        nominal[:self.initial_front] = supported[:self.initial_front]
        if self.formation.nominal == 'axis':
            nominal = supported
        change = gain[:,None]*(nominal-observed)
        return observed+change, dict(formation_weights=self.formation_weights.copy(),
            formation_radius_mm=self.radius_reference, formation_pitch_sign=self.pitch_sign,
            formation_phase=self.helix_phase, formation_nominal=nominal,
            formation_observed=observed, formation_change=change, formation_gain=gain)

    def configuration(self):
        return dict(**super().configuration(), formation=asdict(self.formation),
                    pitch_mm=self.pitch_mm, pitch_sign=self.pitch_sign,
                    principle='measured bending + progressive nominal recovery + measured A-D difference')
