"""Yield with retained support preload until measured transfer, then unload.

This experimental extension changes position references only. The preload
limit is the existing actuator's torque limit divided by position gain, not an
increase in torque capacity. Axes remain known simulation inputs in stage 1.
"""
import math
import numpy as np
from segmented_pole_backbone import smoothstep
from window_coordinated_winding import WindowCoordinatedWinding


class SupportTransferWinding(WindowCoordinatedWinding):
    def __init__(self,*args,support_error_limit,**kwargs):
        super().__init__(*args,**kwargs)
        self.support_error_limit=np.asarray(support_error_limit)
        measured=np.asarray(kwargs['measured'])
        self.middle_preload=np.clip(self.last_target-measured,-self.support_error_limit,self.support_error_limit)
        self.previous_rear=self.rear

    def update_middle_reference(self,points,measured,dt):
        # Capture the load-bearing reference before a rear joint enters the
        # yielding middle. Previously ~96% of this error vanished in one step.
        if self.rear>self.previous_rear:
            ids=slice(self.previous_rear,self.rear)
            self.middle_preload[ids]=np.clip(self.last_target[ids]-measured[ids],
                -self.support_error_limit[ids],self.support_error_limit[ids])
        self.previous_rear=self.rear
        source_distance,target_distance,_,_=self.distances(points[1:-1])
        # Fade the support bias over one link as actual geometry changes pipe
        # association; assigning a joint to a new window alone does not erase it.
        retained=1-smoothstep(np.clip(.5+(source_distance-target_distance)/self.link,0,1))
        middle=self.weights[:,1]>0
        reference=measured+retained*self.middle_preload
        self.middle_reference[middle]+=-math.expm1(-dt/self.options.follow_seconds)*(reference[middle]-self.middle_reference[middle])
        return dict(support_reference_bias=self.middle_preload.copy(),support_retention=retained)

    def configuration(self):
        return dict(**super().configuration(),support_transfer=dict(
            retained_preload='captured position error, bounded by existing actuator capacity',
            error_limit_rad=self.support_error_limit.tolist(),fade_distance_mm=self.link))
